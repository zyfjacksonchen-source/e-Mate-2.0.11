# dsh-file-viewer

External **Workspace File Browser** plugin for DeepSeek Harness (DSH) Web sessions.
It adds a full-screen modal overlay with a lazy workspace file tree on the left and a
preview pane on the right, supporting **text files**, **image files**, and **Markdown**
rendering. Built on the DSH Cordis plugin system as an external Bundle plugin — no DSH
source modifications.

> Sibling project: [`@dsh-external/dsh-markdown-viewer`](https://github.com/deepseek-ai/dsh-markdown-viewer)
> (side panel that previews Markdown only). This plugin is independent and both can be
> installed and used at the same time.

## Features

- Full-screen modal (`shell.overlay`) opened from a session header action
- Lazy-loaded file tree: directories expand on demand, children are cached on collapse
- Multi-type preview:
  - `.md` / `.markdown` → rendered Markdown (DSH `MarkdownText`)
  - text whitelist (`.txt`, `.json`, `.js`, `.ts`, `.yaml`, … plus common extensionless
    files like `README`, `LICENSE`, `Makefile`, `.gitignore`) → UTF-8 text with
    **syntax highlighting** (DSH `CodeBlock` / shiki; TS/JS/JSON/Python/Rust/YAML and
    two dozen more grammars)
  - image whitelist (`.png`, `.jpg`, `.jpeg`, `.gif`, `.webp`, `.bmp`, `.ico`) → inline image
  - anything else → "preview not supported"
- **Open in system app** (`openFile` Remote): the toolbar button spawns the OS default
  opener (`open` on macOS, `xdg-open` on Linux) for the selected file, like Codex
- **File-open routing**: clicking ANY file link in the Web UI opens it in the viewer
  (intercepts `workspaces.openPath`). Files inside a session workspace open with the
  file tree; absolute paths outside every workspace open in **single-file mode**
  (no tree, full-width preview, containment relaxed for the clicked path)
- **Git diff view** (`gitDiff` Remote): toggle per-file working-tree-vs-HEAD diff,
  rendered with the DSH `DiffBlock`; untracked files show as fully added, unchanged
  and binary files get explicit states; diffs are cached per file
- Size guards: `maxTextBytes` / `maxImageBytes` (default 1 MiB each)
- Directory listing capped at 500 entries per directory with a "truncated" hint
- Escape / backdrop click to close; split-ratio drag handle (vertical layout on narrow screens)
- Automatic close and cleanup when switching sessions
- Light/dark theme via `--dsw-alias-*` tokens; zh/en locales
- All filesystem work runs inside the Agent scope with containment checks (`fs.contains`)

## Architecture

```
Header action ──> FileBrowserCoordinator ──> Client Remote (Typert) ──> Host FileBrowserService
                    │  (revision guards, abort,     │                       │
                    │   stale suppression, cache)   ▼                       ▼
                    └──> Store (immer) ◄────── shell.overlay occupant   fs.resolve/contains/stat/
                       (tree + preview state)      + FileTree + PreviewPane   listDir/readText/readBytes
```

- **Host** (`src/index.ts` + `src/host/`): `fileBrowser` Typert Remote namespace with
  `listDirectory` and `readFile`. All paths are resolved against the Agent workspace
  `cwd`, containment-checked, and classified by extension.
- **Client** (`src/client/`): `FileBrowserCoordinator` orchestrates directory loads,
  file reads, request cancellation, stale-result suppression, and connection resets;
  `FileBrowserStore` (in-memory, session-scoped) owns the tree and preview state;
  `FileBrowserOverlay` / `FileTree` / `PreviewPane` render the UI.
- Transport keys are `FsTarget.displayPath`; `targetKey` is never used across the Remote.

## Development

```bash
pnpm install
pnpm run check        # typecheck (host+client) + tests + build + verify:build
pnpm run test         # vitest (needs a prior host build for Typert artifacts)
```

### Build artifacts

| Artifact | Purpose |
| --- | --- |
| `lib/index.js` + `lib/index.d.ts` | Host service |
| `lib/typert.host.js` / `lib/typert.remote-client.js` | Typert Remote descriptors |
| `lib/client.js` | Browser bundle (`window.__ModuleLoader__` entry) |
| `cordis.patch.yml` | Cordis patch inserting the service into the Web profile |

### Fast iteration (rebuild → reinstall)

After editing the plugin, run one command to rebuild, package, re-add it to the
`web` profile, and restart the harness:

```bash
pnpm run reinstall
```

This runs `pack:plugin` (full build + verify + `pnpm pack`), removes the previous
package from the profile, `dsh plugin --profile web add` the fresh tarball, and
restarts the harness. The tarball is self-contained (full `lib/` artifacts), so
there is no stale symlink/hard-link or half-built `lib/` to worry about.

Notes:
- `build:host` alone runs `tsdown` with `clean: true`, which wipes `lib/client.js`;
  always build through `pnpm run build` / `pnpm run reinstall`.
- Client-bundle and composition changes are already hot-reloaded by the Web
  profile's `client-hmr` + patch watching; only Host-side code needs the restart.

## Install into DSH

### 一键安装（推荐）

直接用 `curl` 拉取安装脚本并交给 `bash` 执行，即可从 GitHub 构建并安装到 `web` profile：

```bash
curl -fsSL https://raw.githubusercontent.com/EatherToo/dsh-file-viewer/master/install.sh | bash
```

脚本会依次：检查 Node.js / pnpm / `dsh` 前置依赖 → 下载源码到临时目录 →
`pnpm install` + `pnpm run pack:plugin`（构建 host + client + typert 并打包）→
`dsh plugin --profile web add <tarball>` 写入 `web` profile →
若检测到运行中的 `dsh web` 则自动重启使其生效。

可通过环境变量覆盖默认行为：

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `DSH_FILE_VIEWER_REF` | `master` | 安装的分支 / 标签 |
| `DSH_FILE_VIEWER_SLUG` | `EatherToo/dsh-file-viewer` | GitHub `owner/repo`（fork 时可改） |
| `DSH_PROFILE` | `web` | 目标 DSH profile |
| `DSH_PORT` | `3080` | 重启检测使用的端口 |
| `DSH_FILE_VIEWER_NO_RESTART` | `0` | 设为 `1` 不自动重启 harness |

例如安装指定 tag：

```bash
curl -fsSL https://raw.githubusercontent.com/EatherToo/dsh-file-viewer/master/install.sh | DSH_FILE_VIEWER_REF=v0.1.0 bash
```

### 手动安装

```bash
git clone https://github.com/EatherToo/dsh-file-viewer.git
cd dsh-file-viewer
pnpm install
pnpm run pack:plugin                            # 构建 + 校验 + 打包出 dsh-file-viewer-*.tgz
dsh plugin --profile web remove dsh-file-viewer || true
dsh plugin --profile web add "$(pwd)/$(ls -1t dsh-file-viewer-*.tgz | head -1)"
```

### 插件配置

```yaml
# cordis.patch.yml (already inside the package)
- insert:
    - id: dsh-file-viewer
      name: 'dsh-file-viewer'
      config:
        maxTextBytes: 1048576
        maxImageBytes: 1048576
        allowAbsolutePaths: true # 设为 false 可禁止单文件模式读取/打开工作区外路径
```

## Safety

- Path traversal / symlink escapes are rejected by `fs.contains` after canonical resolution
- NUL injection is rejected up front
- Single-file mode (`absolute`) is a deliberate trust expansion: it lets the Web UI read/open absolute paths outside workspaces; only enable this plugin in a trusted UI environment
- Set `allowAbsolutePaths: false` in the plugin config to disable absolute single-file mode entirely
- Files over the configured size limits are rejected without reading
- Version consistency checks (stat before/after read, one retry) prevent torn previews
- No workspace or filesystem → explicit error codes, never a fallback to `process.cwd()`
- Stopping/uninstalling the plugin removes every slot, style, request, and listener

## License

MIT
