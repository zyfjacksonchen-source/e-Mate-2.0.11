import { DirectoryListErrorCode, DirectoryListRequest, DirectoryListResult, FileOpenErrorCode, FileOpenRequest, FileOpenResult, FileReadErrorCode, FileReadRequest, FileReadResult, GitDiffErrorCode, GitDiffRequest, GitDiffResult } from "./types.js";
import s from "@deepseek-ai/schemastery";
import { TypertRemoteService } from "@deepseek-ai/dsh-typert-protocol";
import { FileSystem, FsDirEntry, FsError } from "@deepseek-ai/dsh-fs";
import { Context } from "@deepseek-ai/cordis";
import { Agent } from "@deepseek-ai/dsh-agent";

//#region src/host/extensions.d.ts
/**
 * 扩展名白名单与文件类型分类。
 *
 * 分类规则：
 * - 有扩展名：命中 TEXT_EXTENSIONS → text；命中 IMAGE_EXTENSIONS → image；否则 unsupported。
 * - 无扩展名（含 `.gitignore` 这类隐藏文件，`lastIndexOf('.') === 0`）：
 *   命中 EXTENSIONLESS_TEXT_FILES → text；否则 unsupported。
 * - SVG（`.svg`）属于文本白名单，读取 XML 文本内容，由前端以 CodeBlock 显示源码。
 */
type FileCategory = 'text' | 'image' | 'unsupported';
declare const TEXT_EXTENSIONS: Set<string>;
declare const EXTENSIONLESS_TEXT_FILES: Set<string>;
declare const IMAGE_EXTENSIONS: Set<string>;
/** 按文件名（basename）分类文件类型。 */
declare function classifyFile(name: string): FileCategory;
//#endregion
//#region src/host/git-diff.d.ts
interface GitDiffEnvironment {
  readonly fs: FileSystem;
  readonly cwd: string;
  readonly signal: AbortSignal;
  /** 新内容大小上限（diff 目标受同一文本上限约束） */
  readonly maxTextBytes: number;
  /** git 可执行文件；测试注入 */
  readonly gitCommand?: string;
  readonly onExpectedFailure?: (error: FsError) => void;
}
/**
 * 计算某文件的工作区 ↔ HEAD 差异。
 * - 已跟踪且有更改：oldText = `git show HEAD:<rel>`，newText = fs.readText
 * - 未跟踪：oldText = null（DiffBlock 渲染为整文件新增）
 * - 无更改 / 二进制（非 UTF-8）→ 各自专门 kind
 */
declare function gitDiff(request: GitDiffRequest, environment: GitDiffEnvironment): Promise<GitDiffResult>;
//#endregion
//#region src/host/list-directory.d.ts
/** 单目录返回条目数上限（Phase 1 防护，见技术方案 §8.3）。 */
declare const DEFAULT_MAX_ENTRIES = 500;
interface DirectoryListEnvironment {
  readonly fs: FileSystem;
  readonly cwd: string;
  readonly signal: AbortSignal;
  readonly maxEntries?: number;
  readonly onExpectedFailure?: (error: FsError) => void;
}
declare function validateDirectoryPath(path: string): DirectoryListErrorCode | undefined;
/** 根路径约定：'' 或 undefined 一律视为 '.'（fs.resolve('') 行为未定义）。 */
declare function resolveRootPath(path: string | undefined): string;
declare function sortDirEntries(entries: readonly FsDirEntry[]): FsDirEntry[];
declare function listDirectory(request: DirectoryListRequest, environment: DirectoryListEnvironment): Promise<DirectoryListResult>;
//#endregion
//#region src/host/open-file.d.ts
interface FileOpenEnvironment {
  readonly fs: FileSystem;
  readonly cwd: string;
  readonly signal: AbortSignal;
  /** 注入平台以支持测试；默认取 process.platform */
  readonly platform?: NodeJS.Platform;
  /** 是否允许 absolute 单文件模式打开工作区外路径；默认开启（兼容现有 UI）。 */
  readonly allowAbsolutePaths?: boolean;
  readonly onExpectedFailure?: (error: FsError) => void;
}
/** macOS 用 `open`，Linux 用 `xdg-open`；其他平台不支持。 */
declare function openCommandFor(platform: NodeJS.Platform): string | undefined;
/**
 * 用系统默认应用打开目标文件（类似 Codex 的 open-in-editor）。
 * 用户主动触发、作用于其正在浏览的会话工作区文件；通过
 * `fs.processPath` 取得子进程可用的真实路径后交给系统命令。
 */
declare function openFileWithSystem(request: FileOpenRequest, environment: FileOpenEnvironment): Promise<FileOpenResult>;
//#endregion
//#region src/host/read-file.d.ts
interface FileReadEnvironment {
  readonly fs: FileSystem;
  readonly cwd: string;
  readonly maxTextBytes: number;
  readonly maxImageBytes: number;
  readonly signal: AbortSignal;
  /** 是否允许 absolute 单文件模式读取工作区外路径；默认开启（兼容现有 UI）。 */
  readonly allowAbsolutePaths?: boolean;
  readonly onExpectedFailure?: (error: FsError) => void;
}
declare function validateFilePath(path: string): FileReadErrorCode | undefined;
declare function readFile(request: FileReadRequest, environment: FileReadEnvironment): Promise<FileReadResult>;
//#endregion
//#region src/index.d.ts
interface Config {
  readonly maxTextBytes: number;
  readonly maxImageBytes: number;
  /** 是否允许客户端以 absolute 单文件模式读取/打开工作区外路径 */
  readonly allowAbsolutePaths: boolean;
}
declare module '@deepseek-ai/cordis' {
  interface Context {
    fileBrowser: FileBrowserService;
  }
}
declare class FileBrowserService extends TypertRemoteService {
  static Config: s<Schemastery.ObjectS<{
    maxTextBytes: s<number, number>;
    maxImageBytes: s<number, number>;
    allowAbsolutePaths: s<boolean, boolean>;
  }>, Schemastery.ObjectT<{
    maxTextBytes: s<number, number>;
    maxImageBytes: s<number, number>;
    allowAbsolutePaths: s<boolean, boolean>;
  }>>;
  private readonly maxTextBytes;
  private readonly maxImageBytes;
  private readonly allowAbsolutePaths;
  constructor(ctx: Context, config: Config);
  /** Agent scope 的 cwd 与 fs 解析（同现有 Markdown Viewer 的授权模式）。 */
  private resolveRuntime;
  listDirectory(agent: Agent, request: DirectoryListRequest, signal: AbortSignal): Promise<DirectoryListResult>;
  readFile(agent: Agent, request: FileReadRequest, signal: AbortSignal): Promise<FileReadResult>;
  openFile(agent: Agent, request: FileOpenRequest, signal: AbortSignal): Promise<FileOpenResult>;
  gitDiff(agent: Agent, request: GitDiffRequest, signal: AbortSignal): Promise<GitDiffResult>;
}
//#endregion
export { Config, DEFAULT_MAX_ENTRIES, type DirectoryListErrorCode, type DirectoryListRequest, type DirectoryListResult, EXTENSIONLESS_TEXT_FILES, FileBrowserService, FileBrowserService as default, type FileOpenErrorCode, type FileOpenRequest, type FileOpenResult, type FileReadErrorCode, type FileReadRequest, type FileReadResult, type GitDiffErrorCode, type GitDiffRequest, type GitDiffResult, IMAGE_EXTENSIONS, TEXT_EXTENSIONS, classifyFile, gitDiff, listDirectory, openCommandFor, openFileWithSystem, readFile, resolveRootPath, sortDirEntries, validateDirectoryPath, validateFilePath };