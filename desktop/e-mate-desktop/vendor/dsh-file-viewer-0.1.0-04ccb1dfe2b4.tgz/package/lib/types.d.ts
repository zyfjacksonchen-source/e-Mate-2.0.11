import { FsDirEntry, FsVersion } from "@deepseek-ai/dsh-fs";

//#region src/types.d.ts
interface DirectoryListRequest {
  /** 相对于 workspace cwd 的目录路径；'' 或 '.' 表示工作区根目录 */
  readonly path: string;
  /** 条件版本：目录版本匹配时返回 'unchanged'，避免重复传输 */
  readonly ifVersion?: FsVersion;
}
type DirectoryListErrorCode = 'workspace-unavailable' | 'fs-unavailable' | 'invalid-path' | 'outside-workspace' | 'not-found' | 'not-directory' | 'read-failed';
type DirectoryListResult = {
  readonly kind: 'directory';
  readonly entries: FsDirEntry[];
  readonly version: FsVersion; /** 单目录条目数超过上限时置位，客户端据此提示「已显示前 N 项」 */
  readonly truncated?: boolean;
} | {
  readonly kind: 'unchanged';
  readonly version: FsVersion;
} | {
  readonly kind: 'rejected';
  readonly code: DirectoryListErrorCode;
};
interface FileReadRequest {
  /** 相对于 workspace cwd 的文件路径；absolute 模式下为绝对路径 */
  readonly path: string;
  readonly ifVersion?: FsVersion;
  /**
   * 单文件模式：绝对路径直接解析，跳过 workspace containment 校验
   * （用于从会话外文件链接打开；路径仍必须是绝对路径，否则保持 containment）
   */
  readonly absolute?: boolean;
}
type FileReadErrorCode = 'workspace-unavailable' | 'fs-unavailable' | 'invalid-path' | 'outside-workspace' | 'not-found' | 'not-file' | 'unsupported-type' | 'too-large' | 'not-utf8' | 'file-changing' | 'read-failed';
type FileReadResult = {
  readonly kind: 'text';
  readonly content: string;
  readonly version: FsVersion;
  readonly size: number;
} | {
  readonly kind: 'image';
  readonly mime: string; /** Base64 编码的图片字节 */
  readonly data: string;
  readonly version: FsVersion;
  readonly size: number;
} | {
  readonly kind: 'unchanged';
  readonly version: FsVersion;
} | {
  readonly kind: 'rejected';
  readonly code: FileReadErrorCode;
};
interface FileOpenRequest {
  /** 相对于 workspace cwd 的文件路径；absolute 模式下为绝对路径 */
  readonly path: string;
  /** 单文件模式：绝对路径直接解析，跳过 workspace containment 校验 */
  readonly absolute?: boolean;
}
type FileOpenErrorCode = 'workspace-unavailable' | 'fs-unavailable' | 'invalid-path' | 'outside-workspace' | 'not-found' | 'not-file' | 'unsupported-platform' | 'open-failed';
type FileOpenResult = {
  readonly kind: 'opened';
} | {
  readonly kind: 'rejected';
  readonly code: FileOpenErrorCode;
};
interface GitDiffRequest {
  /** 相对于 workspace cwd 的文件路径（必须位于工作区内） */
  readonly path: string;
}
type GitDiffErrorCode = 'workspace-unavailable' | 'fs-unavailable' | 'invalid-path' | 'outside-workspace' | 'not-found' | 'not-file' | 'too-large' | 'not-git-repo' | 'git-error';
type GitDiffResult = {
  readonly kind: 'diff'; /** HEAD 版本内容；未跟踪文件为 null（整文件视为新增） */
  readonly oldText: string | null; /** 当前工作区文件内容 */
  readonly newText: string; /** 新内容字节数 */
  readonly size: number;
} | {
  readonly kind: 'unchanged';
} | {
  readonly kind: 'binary';
} | {
  readonly kind: 'rejected';
  readonly code: GitDiffErrorCode;
};
//#endregion
export { DirectoryListErrorCode, DirectoryListRequest, DirectoryListResult, FileOpenErrorCode, FileOpenRequest, FileOpenResult, FileReadErrorCode, FileReadRequest, FileReadResult, GitDiffErrorCode, GitDiffRequest, GitDiffResult };